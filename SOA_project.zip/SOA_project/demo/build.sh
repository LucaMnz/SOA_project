#!/bin/bash

gcc -pthread demo.c -o demo
