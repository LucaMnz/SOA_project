#ifndef DEV_HANDLER_H
#define DEV_HANDLER_H

/* device utility */

int register_dev(void);

void unregister_dev(void);

#endif
